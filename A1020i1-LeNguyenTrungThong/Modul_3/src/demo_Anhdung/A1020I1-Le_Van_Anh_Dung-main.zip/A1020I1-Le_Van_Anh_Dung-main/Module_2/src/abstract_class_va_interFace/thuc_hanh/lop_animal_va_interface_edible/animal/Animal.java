package abstract_class_va_interface.thuc_hanh.lop_animal_va_interface_edible.animal;

public abstract class Animal {
    public abstract String makeSound();
}
