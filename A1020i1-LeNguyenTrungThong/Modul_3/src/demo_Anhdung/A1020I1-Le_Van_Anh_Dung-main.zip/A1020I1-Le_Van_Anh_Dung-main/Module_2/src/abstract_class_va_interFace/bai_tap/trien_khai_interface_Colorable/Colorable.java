package abstract_class_va_interface.bai_tap.trien_khai_interface_Colorable;


public interface Colorable {
    void howToColor();
}
