package introduction_to_java.thuc_hanh.hien_thi_thoi_gian_he_thong;

import java.util.Date;

public class system_time {
    public static void main(String[] args) {
        Date now = new Date();
        System.out.println("Now is: "+now);
    }
}
