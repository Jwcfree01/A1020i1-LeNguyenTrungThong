package abstract_class_va_interface.bai_tap.trien_khai_interface_Resizeable;

import abstract_class_va_interface.bai_tap.trien_khai_interface_Colorable.Colorable;

public class SquareTest {
    public static void main(String[] args) {
        Square square = new Square();
        System.out.println(square);

        square = new Square(2.3);
        System.out.println(square);

        square = new Square(5.8, "yellow", true);
        square.resize(100);
        System.out.println(square);

        Colorable colorable = square;
        colorable.howToColor();
    }
}
