package test;

public class TestShape {
    public static void main(String[] args) {

        Shape shape = new Shape("green");
        System.out.println(shape);
        Shape shape2 = new Shape();
        System.out.println(shape2);
    }
}
