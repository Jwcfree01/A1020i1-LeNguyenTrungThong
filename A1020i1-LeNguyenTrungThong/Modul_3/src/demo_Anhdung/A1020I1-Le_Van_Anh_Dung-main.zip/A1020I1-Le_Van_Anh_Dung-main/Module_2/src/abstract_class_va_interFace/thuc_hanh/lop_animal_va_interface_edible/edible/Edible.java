package abstract_class_va_interface.thuc_hanh.lop_animal_va_interface_edible.edible;

public interface Edible {
    String howToEat();
}
