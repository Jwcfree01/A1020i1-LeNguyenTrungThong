package CaseStudy.controllers;

import CaseStudy.manage.ManageBooking;

import java.util.Scanner;

public class ControllerBooking {
    private final static ManageBooking manage = new ManageBooking();


//    public static void main(String[] args) {
//        Scanner input = new Scanner(System.in);
//        ControllerBooking booking = new ControllerBooking();
//        booking.displayMainMenu(input);
//    }
}
