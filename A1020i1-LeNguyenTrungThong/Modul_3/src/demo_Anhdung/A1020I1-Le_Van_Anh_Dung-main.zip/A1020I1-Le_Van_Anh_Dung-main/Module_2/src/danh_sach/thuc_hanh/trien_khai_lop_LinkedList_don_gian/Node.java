package danh_sach.thuc_hanh.trien_khai_lop_LinkedList_don_gian;

public class Node {
}
