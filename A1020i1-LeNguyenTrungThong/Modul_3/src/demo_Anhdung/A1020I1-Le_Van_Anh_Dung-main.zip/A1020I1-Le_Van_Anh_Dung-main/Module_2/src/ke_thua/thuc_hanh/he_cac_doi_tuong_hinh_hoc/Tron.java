package ke_thua.thuc_hanh.he_cac_doi_tuong_hinh_hoc;

public class Tron {
}
