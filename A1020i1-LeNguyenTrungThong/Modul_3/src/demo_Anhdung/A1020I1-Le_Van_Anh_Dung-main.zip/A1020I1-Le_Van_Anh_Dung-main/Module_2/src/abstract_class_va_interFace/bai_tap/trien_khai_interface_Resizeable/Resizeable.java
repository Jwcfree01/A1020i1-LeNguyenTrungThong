package abstract_class_va_interface.bai_tap.trien_khai_interface_Resizeable;

public interface Resizeable {
    void resize(double percent);
    double getArea();
}
