package abstract_class_va_interface.thuc_hanh.lop_animal_va_interface_edible.fruit;

import abstract_class_va_interface.thuc_hanh.lop_animal_va_interface_edible.edible.Edible;

public abstract class Fruit implements Edible {

}
