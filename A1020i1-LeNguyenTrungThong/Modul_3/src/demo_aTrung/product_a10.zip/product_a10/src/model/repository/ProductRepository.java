package model.repository;

import model.Product;

public interface ProductRepository extends CRUDInterface<Product>{
}
