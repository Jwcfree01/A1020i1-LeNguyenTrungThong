package com.example.demo.Service;

import com.example.demo.model.ECommerce;

import java.util.List;

public interface ECommerceService {
    List<ECommerce> findAll();
}
